package amazonp;

public class demo {

}
