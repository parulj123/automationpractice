package amazonp;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Amazon {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
	 System.setProperty("webdriver.chrome.driver", "C://Users//parulj//Desktop//chrome//chromedriver");
		 
		 WebDriverManager.chromedriver().setup();
		  String url = "https://www.amazon.in/";
		 
		    // Start session (opens browser)
		    WebDriver driver = new ChromeDriver();
		    // Lunch url
		    driver.navigate().to("https://www.amazon.in/");  
		    
		    //Maximize window
		    driver.manage().window().maximize();
		    //Delay execution for 5 seconds to view the maximize operation
		    Thread.sleep(5000);
		    
		    //get page title
		    String Actaultitle=driver.getTitle();
		    System.out.println("page titleis : " +Actaultitle);
		    String Expectedtitle="Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
		    if (Actaultitle.equals(Expectedtitle)) {
                System.out.println("Test Passed! and title is same");
			       } 
		      else {
			                  System.out.println("Test Failed and Title is not same");
			       }
		    
		  //Double click the button to launch an alertbox
		    Actions action = new Actions(driver);
		    WebElement link =driver.findElement(By.xpath("//a[text()='Amazon Pay']"));
		    action.doubleClick(link).perform();
		    Thread.sleep(3000);
			//Navigating back in browser 
			driver.navigate().back();
		    //window close
		    driver.quit();
	}

}
